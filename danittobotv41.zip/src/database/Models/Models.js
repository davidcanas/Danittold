module.exports = {
    guilds: require('./Guild')
}