module.exports = {
    guilds: require('./Guild'),
    cmds: require("./cmds"),
    users: require("./User")
}