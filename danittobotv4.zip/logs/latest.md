[21/12/2021 @ 11:29:57] - **Comando**: `perfil ` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 11:38:19] - **Comando**: `eval client.api.guilds('792018456786370590').members('852650555254767676').patch({
,data:,{
,communication_disabled_until:,new,Date(Date.now(),+,60000)
,},
,reason:,'motivo,do,timeout',//,opcional,,vai,aparecer,no,audit,logs
});` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 11:38:30] - **Comando**: `eval this.client.api.guilds('792018456786370590').members('852650555254767676').patch({
,data:,{
,communication_disabled_until:,new,Date(Date.now(),+,60000)
,},
,reason:,'motivo,do,timeout',//,opcional,,vai,aparecer,no,audit,logs
});` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 11:39:41] - **Comando**: `eval this.client.api.guilds('792018456786370590').members('733963304610824252').patch({
,data:,{
,communication_disabled_until:,new,Date(Date.now(),+,60000)
,},
,reason:,'motivo,do,timeout',//,opcional,,vai,aparecer,no,audit,logs
});` executado por `shushi#1245 (852650555254767676)`
[21/12/2021 @ 11:41:23] - **Comando**: `eval ctx.msg.channel.delete()` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 11:44:15] - **Interação**: `setwelcomechannel` executado por `shushi#1245 (852650555254767676)`
[21/12/2021 @ 11:45:36] - **Comando**: `setwelcomechannel on,<#792018815646302228>` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 11:45:51] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:1:10] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:2:37] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:3:37] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:4:14] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:5:9] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:5:24] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:13:25] - **Comando**: `help ` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:14:9] - **Comando**: `help ` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:15:0] - **Comando**: `eval this.client.emit("guildMemberAdd",,ctx.msg.member)` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:15:34] - **Interação**: `setwelcomechannel` executado por `Canas#0514 (733963304610824252)`
[21/12/2021 @ 12:15:43] - **Comando**: `eval this.client.emit("guildMemberAdd",,ctx.msg.member)` executado por `Canas#0514 (733963304610824252)`
